namespace AxelPortfolio.Models
{
    public class Skill
    {
        public string? Name { get; set; }
        public string? LogoUrl { get; set; }  // Ruta del logo de la habilidad
    }
}
