using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace PortafolioAxel.Pages
{
    public class ContactoModel : PageModel
    {
        private readonly IConfiguration _configuration;

        // Inicialización de FormModel en el constructor
        public ContactoModel(IConfiguration configuration)
        {
            _configuration = configuration;
            FormModel = new ContactoFormModel(); // Se inicializa la propiedad FormModel
        }

        [BindProperty]
        public ContactoFormModel FormModel { get; set; }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (ModelState.IsValid)
            {
                var fromEmail = _configuration["EmailSettings:FromEmail"];
                var fromName = _configuration["EmailSettings:FromName"];
                var smtpPortString = _configuration["EmailSettings:SMTPPort"];

                if (string.IsNullOrEmpty(fromEmail))
                {
                    ModelState.AddModelError(string.Empty, "El correo electrónico de origen no está configurado.");
                    return Page();
                }

                if (!int.TryParse(smtpPortString, out int smtpPort))
                {
                    ModelState.AddModelError(string.Empty, "El puerto SMTP no está configurado correctamente.");
                    return Page();
                }

                var smtpClient = new SmtpClient(_configuration["EmailSettings:SMTPServer"])
                {
                    Port = smtpPort,
                    Credentials = new NetworkCredential(_configuration["EmailSettings:SMTPUsername"], _configuration["EmailSettings:SMTPPassword"]),
                    EnableSsl = true,
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(fromEmail, fromName ?? "No Name"),
                    Subject = "Nuevo mensaje de contacto",
                    Body = $"Nombre de la empresa: {FormModel.Empresa}\n" +
                           $"Nombre del contacto: {FormModel.NombreContacto}\n" +
                           $"Correo electrónico: {FormModel.Email}\n" +
                           $"Teléfono: {FormModel.Telefono}\n" +
                           $"Mensaje: {FormModel.Mensaje}",
                    IsBodyHtml = false,
                };

                mailMessage.To.Add(fromEmail); // Envía el correo a ti mismo

                await smtpClient.SendMailAsync(mailMessage);

                return RedirectToPage("Confirmacion");
            }

            return Page();
        }
    }

    public class ContactoFormModel
    {
        [Required]
        public string? Empresa { get; set; }

        [Required]
        public string? NombreContacto { get; set; }

        [Required]
        [EmailAddress]
        public string? Email { get; set; }

        [Required]
        [Phone]
        public string? Telefono { get; set; }

        public string? Mensaje { get; set; }
    }
}
